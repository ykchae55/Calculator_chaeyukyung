package ����;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Calc {
 int sss = 100; 
 
 JFrame frame = new JFrame("����");
 JLabel label = new JLabel("A Label");
 JPanel jpnorth = new JPanel();
 JPanel jpcenter = new JPanel();
 JPanel jpsouth = new JPanel();
 JTextField jtfield = new JTextField();
 JButton backspace = null;
 JButton cancel = null;
 JButton[] buttons = null;
 
 
 public Calc() {
  initDisplay();
 }

 public void initDisplay() {
	 	 
  jtfield = new JTextField("0");
  jtfield.setEditable(false);
  jtfield.setBackground(new Color(255,255,255));
  jtfield.setHorizontalAlignment(JTextField.RIGHT);
  
  
  jpnorth = new JPanel();
  jpnorth.setLayout(new BorderLayout()); 
  
  jpcenter = new JPanel();
  jpcenter.setLayout(new GridLayout(1,2));
  jpsouth = new JPanel();
  jpsouth.setLayout(new GridLayout(4,4,4,4));
  
  backspace = new JButton();
  backspace.setText("backspace");
  backspace.setBackground(new Color(255,255,255));
  backspace.setFont(new Font("����", Font.BOLD,14));
  backspace.setForeground(new Color(0,61,255));

  cancel = new JButton();
  cancel.setText("C");
  cancel.setBackground(new Color(255,255,255));
  cancel.setFont(new Font("����", Font.BOLD,14));
  cancel.setForeground(new Color(0,61,255));

  buttons = new JButton[16];
  String strbutton[] = {
      "7","8","9","/",
      "4","5","6","*",
      "1","2","3","+",
      "0",".","=","-"
      };
  
  for(int i=0; i<buttons.length; i++){

   buttons[i] = new JButton();
   buttons[i].setText(strbutton[i]); 
   buttons[i].setBackground(new Color(255,255,255));
   buttons[i].setForeground(new Color(0,61,255));
   buttons[i].setFont(new Font("����", Font.BOLD,14));
   jpsouth.add(buttons[i]);
   
  }

  jpnorth.add("North",jtfield);
  jpcenter.add("Center",backspace);
  jpcenter.add("Center",cancel);
  
  frame.add("South",jpsouth);
  frame.add("Center",jpcenter);
  frame.add("North",jpnorth);

  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  frame.setSize(300, 260);
  frame.setVisible(true);
  frame.add(label);

  label.setText("better");
  
 }

}


